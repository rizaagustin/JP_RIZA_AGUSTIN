Rest API Menggunakan LARAVEL 9
Cara Akses API Soal No 1
http://localhost:8000/api/data

Cara Akses API Filter Soal No 2
http://localhost:8000/api/data/CIDENG
